Frog VRC6 FamiStudio Pack (4.4.x)

What this is
- A FamiStudio text project aimed at FamiStudio 4.4.x with 5 short VRC6 frog sound effects.
- Each song is one sound effect:
  01_Frog_Ribbit
  02_Frog_Jump
  03_Frog_Land
  04_Frog_Walk
  05_Frog_Idle_Shuffle

Import
1. Open FamiStudio desktop.
2. Open the file: frog_vrc6_famistudio_4_4_x.txt
3. Audition each song.
4. Tweak volumes, duty cycles, note lengths, and slide targets to taste.

Important
- FamiStudio text import is version-sensitive. This file targets the 4.4.x text format.
- If import fails because your build is not 4.4.x, use the sequence reference + CSV fallback in this zip and recreate the songs manually in a fresh VRC6 project.

Suggested mixer behavior
- Keep VRC6 saw under control. These instruments are authored assuming the saw feels best around Half master volume.

Suggested export flow
- Export each song as a sound effect after you audition it.
- For engine export, keep one song = one SFX and name/order them exactly how you plan to reference them in code.

Files
- famistudio/frog_vrc6_famistudio_4_4_x.txt : importable project text for FamiStudio 4.4.x
- reference/frog_vrc6_sequence_reference.md  : quick human-readable per-sfx build guide
- reference/frog_vrc6_song_map.csv           : names and intended engine ids
- original_wavs/*.wav                        : your original reference WAVs
