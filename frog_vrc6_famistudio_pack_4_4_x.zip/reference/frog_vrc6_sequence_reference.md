# Frog VRC6 Sequence Reference

This is the human-readable fallback if the text import version does not match your installed FamiStudio build.

## Global project setup
- Expansion: VRC6
- Tempo mode: FamiStudio
- Suggested note length: 1 frame for SFX work
- Saw master volume: Half on saw instruments

## Instruments
- **FrogPulseBright**: bright VRC6 square, fast decay, duty around 2
- **FrogPulseSoft**: softer VRC6 square, faster decay, duty around 1
- **FrogClick**: tiny short transient for attack/accent
- **FrogSawBody**: main croak body, saw, medium decay
- **FrogSawSoft**: soft saw for support/body
- **FrogNoiseThud**: short landing/body slap noise
- **FrogNoiseSoft**: soft grit for tiny movement sounds

## 01_Frog_Ribbit
- Length: 20 frames
- VRC6Saw: C3 -> slide to G2, cut around frame 9
- VRC6Square1: G4 -> slide to D4, cut around frame 6
- VRC6Square2: short attack at frame 0, tiny secondary pulse at frame 4
- Noise: tiny single-frame grit at frame 0
- Intent: "rrri-bit" with saw carrying the chest/body

## 02_Frog_Jump
- Length: 16 frames
- VRC6Square1: C4 -> slide up to G4, cut around frame 5
- VRC6Saw: G2 -> slide up to C3, cut around frame 4
- Noise: tiny 1-frame bite at frame 0
- Intent: springy hop with a little body underneath

## 03_Frog_Land
- Length: 12 frames
- Noise: low, short thud at frame 0
- VRC6Saw: low body note around E2, cut around frame 4
- VRC6Square1: tiny click at frame 0
- Intent: soft body slap, not a heavy stomp

## 04_Frog_Walk
- Length: 16 frames
- VRC6Square1: two soft ticks at frames 0 and 8
- Noise: two matching grit taps at frames 0 and 8
- VRC6Square2: very low-volume accent ticks under the main steps
- Intent: two-step footfall rhythm

## 05_Frog_Idle_Shuffle
- Length: 16 frames
- VRC6Square1: soft ticks at frames 2 and 9
- Noise: soft grit at frames 3 and 10
- VRC6Saw: tiny body motion under the first shuffle
- Intent: a little wiggle/body reset while stationary

## Suggested engine IDs
- 00 frog_ribbit
- 01 frog_jump
- 02 frog_land
- 03 frog_walk
- 04 frog_idle_shuffle
